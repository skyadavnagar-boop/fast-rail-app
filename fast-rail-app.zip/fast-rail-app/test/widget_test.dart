import 'package:flutter_test/flutter_test.dart';
import 'package:fast_rail_app/main.dart';

void main() {
  testWidgets('Shows the Tatkal passenger form', (WidgetTester tester) async {
    await tester.pumpWidget(const FastRailApp());

    expect(find.text('Tatkal autofill assistant'), findsOneWidget);
    expect(find.text('Passenger Name'), findsOneWidget);
    expect(find.text('Age'), findsOneWidget);
    expect(find.text('Gender'), findsOneWidget);
    expect(find.text('Open IRCTC'), findsOneWidget);
  });
}
