package com.example.fast_rail_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
