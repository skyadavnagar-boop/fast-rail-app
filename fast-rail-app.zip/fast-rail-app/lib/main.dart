import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

void main() {
  runApp(const FastRailApp());
}

class FastRailApp extends StatelessWidget {
  const FastRailApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fast Rail App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const TatkalAssistantScreen(),
    );
  }
}

class TatkalAssistantScreen extends StatefulWidget {
  const TatkalAssistantScreen({super.key});

  @override
  State<TatkalAssistantScreen> createState() => _TatkalAssistantScreenState();
}

class _TatkalAssistantScreenState extends State<TatkalAssistantScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _ageController = TextEditingController();
  String? _gender;

  @override
  void dispose() {
    _nameController.dispose();
    _ageController.dispose();
    super.dispose();
  }

  void _openIrctc() {
    if (!_formKey.currentState!.validate()) return;

    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => PassengerWebViewPage(
          passengerName: _nameController.text.trim(),
          age: _ageController.text.trim(),
          gender: _gender!,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tatkal autofill assistant')),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      'Passenger details',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Enter one passenger’s details, then open IRCTC and '
                      'use the lightning button to fill the booking form.',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 28),
                    TextFormField(
                      controller: _nameController,
                      textCapitalization: TextCapitalization.words,
                      textInputAction: TextInputAction.next,
                      decoration: const InputDecoration(
                        labelText: 'Passenger Name',
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) =>
                          value == null || value.trim().isEmpty
                          ? 'Enter the passenger name'
                          : null,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _ageController,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      textInputAction: TextInputAction.done,
                      decoration: const InputDecoration(
                        labelText: 'Age',
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) {
                        final age = int.tryParse(value ?? '');
                        if (age == null || age < 1 || age > 125) {
                          return 'Enter an age between 1 and 125';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      value: _gender,
                      decoration: const InputDecoration(
                        labelText: 'Gender',
                        border: OutlineInputBorder(),
                      ),
                      items: const [
                        DropdownMenuItem(value: 'Male', child: Text('Male')),
                        DropdownMenuItem(
                          value: 'Female',
                          child: Text('Female'),
                        ),
                        DropdownMenuItem(
                          value: 'Transgender',
                          child: Text('Transgender'),
                        ),
                      ],
                      onChanged: (value) => setState(() => _gender = value),
                      validator: (value) =>
                          value == null ? 'Select a gender' : null,
                    ),
                    const SizedBox(height: 24),
                    FilledButton.icon(
                      onPressed: _openIrctc,
                      icon: const Icon(Icons.open_in_browser),
                      label: const Text('Open IRCTC'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class PassengerWebViewPage extends StatefulWidget {
  const PassengerWebViewPage({
    required this.passengerName,
    required this.age,
    required this.gender,
    super.key,
  });

  final String passengerName;
  final String age;
  final String gender;

  @override
  State<PassengerWebViewPage> createState() => _PassengerWebViewPageState();
}

class _PassengerWebViewPageState extends State<PassengerWebViewPage> {
  InAppWebViewController? _webViewController;
  bool _isLoading = true;
  bool _isFilling = false;

  Future<void> _autofillPassenger() async {
    final controller = _webViewController;
    if (controller == null || _isFilling) return;

    setState(() => _isFilling = true);
    try {
      final script =
          '''
(() => {
  const desired = {
    name: ${jsonEncode(widget.passengerName)},
    age: ${jsonEncode(widget.age)},
    gender: ${jsonEncode(widget.gender)}
  };
  const normalize = (value) => (value || '').replace(/\\s+/g, ' ').trim().toLowerCase();
  const visible = (element) => !!element && element.getClientRects().length > 0;
  const labelsFor = (element) => {
    const labels = [];
    if (element.id) {
      document.querySelectorAll('label[for]').forEach((label) => {
        if (label.htmlFor === element.id) labels.push(label.innerText || label.textContent || '');
      });
    }
    const closestLabel = element.closest('label');
    if (closestLabel) labels.push(closestLabel.innerText || closestLabel.textContent || '');
    const parent = element.parentElement;
    if (parent) labels.push(parent.innerText || parent.textContent || '');
    return labels.join(' ');
  };
  const metadata = (element) => normalize([
    element.getAttribute('aria-label'),
    element.getAttribute('placeholder'),
    element.getAttribute('name'),
    element.id,
    element.getAttribute('autocomplete'),
    labelsFor(element)
  ].filter(Boolean).join(' '));
  const rank = (element, patterns) => {
    const text = metadata(element);
    return patterns.reduce((score, pattern) => score + (pattern.test(text) ? 1 : 0), 0);
  };
  const findBest = (elements, patterns, minimumScore) => Array.from(elements)
    .filter(visible)
    .map((element) => ({ element, score: rank(element, patterns) }))
    .filter((candidate) => candidate.score >= minimumScore)
    .sort((a, b) => b.score - a.score)[0]?.element || null;
  const setInput = (element, value) => {
    element.focus();
    const setter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype, 'value'
    ).set;
    setter.call(element, value);
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.blur();
  };

  let filled = 0;
  const nameField = findBest(
    document.querySelectorAll('input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=search])'),
    [/passenger/, /travell?er/, /name/],
    1
  );
  if (nameField) {
    setInput(nameField, desired.name);
    filled++;
  }

  const ageField = findBest(
    document.querySelectorAll('input:not([type=hidden]):not([type=checkbox]):not([type=radio])'),
    [/age/, /years? old/],
    1
  );
  if (ageField) {
    setInput(ageField, desired.age);
    filled++;
  }

  const genderWords = desired.gender.toLowerCase();
  const genderOptions = (element) =>
    element.tagName === 'SELECT' &&
    Array.from(element.options).some((option) =>
      /^(male|female|transgender|m|f)\$/.test(normalize(option.text || option.value))
    );
  const genderField = findBest(
    document.querySelectorAll('select,[role=combobox]'),
    [/gender/, /sex/],
    1
  ) || Array.from(document.querySelectorAll('select')).find(genderOptions) || null;
  if (genderField && genderField.tagName === 'SELECT') {
    const option = Array.from(genderField.options).find((item) => {
      const value = normalize(item.text || item.value);
      return value === genderWords ||
        (genderWords === 'male' && value === 'm') ||
        (genderWords === 'female' && value === 'f');
    });
    if (option) {
      const setter = Object.getOwnPropertyDescriptor(
        window.HTMLSelectElement.prototype, 'value'
      ).set;
      setter.call(genderField, option.value);
      genderField.dispatchEvent(new Event('input', { bubbles: true }));
      genderField.dispatchEvent(new Event('change', { bubbles: true }));
      filled++;
    }
  } else if (genderField) {
    genderField.click();
    const option = Array.from(document.querySelectorAll(
      '[role=option],mat-option,.ng-option,li'
    )).find((item) => normalize(item.innerText || item.textContent) === genderWords);
    if (option) {
      option.click();
      filled++;
    }
  }

  const checkbox = Array.from(document.querySelectorAll('input[type=checkbox]'))
    .filter(visible)
    .map((element) => {
      const text = normalize([
        element.getAttribute('aria-label'),
        element.title,
        labelsFor(element),
        element.parentElement?.parentElement?.innerText
      ].filter(Boolean).join(' '));
      const matches = /confirm|confirmed/.test(text) && /berth/.test(text);
      return { element, matches };
    })
    .find((candidate) => candidate.matches)?.element;
  let checked = false;
  if (checkbox) {
    if (!checkbox.checked) checkbox.click();
    checked = checkbox.checked;
  }
  return JSON.stringify({ filled, checked });
})()
''';
      final rawResult = await controller.evaluateJavascript(source: script);
      final result = rawResult is String ? jsonDecode(rawResult) : rawResult;
      final filled = result is Map ? result['filled'] as int? ?? 0 : 0;
      final checked = result is Map ? result['checked'] == true : false;
      if (!mounted) return;
      final message = filled == 3
          ? 'Passenger details filled${checked ? ' and confirm berths selected' : ''}. '
                'Review them before continuing.'
          : 'Filled $filled of 3 passenger fields'
                '${checked ? ' and selected confirm berths' : ''}. '
                'Review the form and complete any remaining fields.';
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Could not autofill this page. Please enter the details manually.',
          ),
        ),
      );
    } finally {
      if (mounted) setState(() => _isFilling = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('IRCTC'),
        actions: [
          IconButton(
            tooltip: 'Autofill passenger details',
            onPressed: _webViewController == null || _isFilling
                ? null
                : _autofillPassenger,
            icon: _isFilling
                ? const SizedBox.square(
                    dimension: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.bolt),
          ),
        ],
      ),
      body: Column(
        children: [
          if (_isLoading) const LinearProgressIndicator(minHeight: 2),
          Expanded(
            child: InAppWebView(
              initialUrlRequest: URLRequest(
                url: WebUri('https://www.irctc.co.in/nget/'),
              ),
              initialSettings: InAppWebViewSettings(
                javaScriptEnabled: true,
                domStorageEnabled: true,
                blockNetworkImage: true,
              ),
              onWebViewCreated: (controller) {
                _webViewController = controller;
                setState(() {});
              },
              onLoadStart: (controller, url) {
                if (mounted) setState(() => _isLoading = true);
              },
              onLoadStop: (controller, url) {
                if (mounted) setState(() => _isLoading = false);
              },
              onReceivedError: (controller, request, error) {
                if (request.isForMainFrame == true && mounted) {
                  setState(() => _isLoading = false);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'Page failed to load: ${error.description}',
                      ),
                    ),
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}
